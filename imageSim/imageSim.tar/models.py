from profiles import Sersic as SersicP, Gauss as GaussP
from math import pi

def cnts2mag(cnts,zp):
    from math import log10
    return -2.5*log10(cnts) + zp

_SersicPars = [['amp','n','pa','q','re','x','y'],
                ['logamp','n','pa','q','re','x','y'],
                ['amp','n','q','re','theta','x','y'],
                ['logamp','n','q','re','theta','x','y']]

class Sersic(SersicP):

    def __init__(self,name,var=None,const=None,convolve=0):
        if const is None:
            const = {}
        if var is None:
            var = {}
        # Check for all keys to be set
        keys = var.keys()+const.keys()
        keys.sort()
        if keys not in _SersicPars:
            print "Not all parameters defined!"
            df
        self.keys = keys
        self.values = {}
        self.vmap = {}
        for key in var.keys():
            self.values[key] = None
            self.vmap[var[key]] = key
        for key in const.keys():
            self.values[key] = const[key]
        SersicP.__init__(self,x=None,y=None,q=None,pa=None,re=None,amp=None,n=None)
        self.setValues()
        self.name = name
        self.convolve = convolve

    def __setattr__(self,key,value):
        if key=='pa':
            self.__dict__['pa'] = value
            if value is not None:
                self.__dict__['theta'] = value*pi/180.
        elif key=='theta':
            if value is not None:
                self.__dict__['pa'] = value*180./pi
            self.__dict__['theta'] = value
        elif key=='logamp':
            if value is not None:
                self.__dict__['amp'] = 10**value
        else:
            self.__dict__[key] = value


    def setValues(self):
        self.x = self.values['x']
        self.y = self.values['y']
        self.q = self.values['q']
        if 'pa' in self.keys:
            self.pa = self.values['pa']
        else:
            self.theta = self.values['theta']
        self.re = self.values['re']
        if 'amp' in self.keys:
            self.amp = self.values['amp']
        elif self.values['logamp'] is not None:
            self.amp = 10**self.values['logamp']
        self.n = self.values['n']


    def getMag(self,amp,zp):
        from scipy.special import gamma
        from math import exp,pi
        n = self.n
        re = self.re
        k = 2.*n-1./3+4./(405.*n)+46/(25515.*n**2)
        cnts = (re**2)*amp*exp(k)*n*(k**(-2*n))*gamma(2*n)*2*pi
        return cnts2mag(cnts,zp)

    def Mag(self,zp):
        return self.getMag(self.amp,zp)

    def setPars(self,pars):
        for key in self.vmap:
            self.values[self.vmap[key]] = pars[key]
        self.setValues()


class Gauss(GaussP):
    def __init__(self,name,var=None,const=None,convolve=0):
        if const is None:
            const = {}
        if var is None:
            var = {}
        # Check for all keys to be set
        keys = var.keys()+const.keys()
        keys.sort()
        if 'r0' not in keys:
            keys.append('r0')
            keys.sort()
        if keys!=['amp','pa','q','r0','sigma','x','y']:
            print "Not all parameters defined!"
            df
        self.values = {'r0':None}
        self.vmap = {}
        for key in var.keys():
            self.values[key] = None
            self.vmap[var[key]] = key
        for key in const.keys():
            self.values[key] = const[key]
        GaussP.__init__(self,x=None,y=None,q=None,pa=None,sigma=None,amp=None,r0=None)
        self.setValues()
        self.name = name
        self.convolve = convolve


    def setValues(self):
        self.x = self.values['x']
        self.y = self.values['y']
        self.q = self.values['q']
        self.pa = self.values['pa']
        self.sigma = self.values['sigma']
        self.amp = self.values['amp']
        self.r0 = self.values['r0']


    def getMag(self,amp,zp):
        from math import exp,pi
        if self.r0 is None:
            cnts = amp/(2*pi*self.sigma**2)
        else:
            from scipy.special import erf
            r0 = self.r0
            s = self.sigma
            r2pi = (2*pi)**0.5
            cnts = amp*pi*s*(r2pi*r0*(1.+erf(r0/(s*2**0.5)))+2*s*exp(-0.5*r0**2/s**2))
        return cnts2mag(cnts,zp)

    def Mag(self,zp):
        return self.getMag(self.amp,zp)

    def setPars(self,pars):
        for key in self.vmap:
            self.values[self.vmap[key]] = pars[key]
        self.setValues()

